import { Request, Response, NextFunction } from "express";
import { Prisma } from "@prisma/client";
import { prisma } from "../lib/prisma";
import {
  ConciliarPagoSchema,
  ConciliarPagoDTO,
} from "../validators/transaction.validator";
import {
  NotFoundError,
  UnprocessableEntityError,
  BadRequestError,
} from "../lib/errors";


// =============================================================================
// POST /api/v1/cobranza/conciliar-pago
// =============================================================================

export async function conciliarPago(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const dto: ConciliarPagoDTO = ConciliarPagoSchema.parse(req.body);

    // ── Cargar cuenta por cobrar con relaciones necesarias ──────────────────
    const ar = await prisma.accountReceivable.findUnique({
      where: { id: dto.account_receivable_id },
      include: {
        transaction: {
          include: {
            customer: true,
            transaction_lines: { include: { product: true } },
          },
        },
        customer: true,
      },
    });

    if (!ar) throw new NotFoundError("Cuenta por cobrar no encontrada");

    if (ar.status === "CONCILIADA") {
      throw new UnprocessableEntityError(
        "Esta cuenta ya fue conciliada en su totalidad",
        "AR_YA_CONCILIADA"
      );
    }

    if (ar.status === "VENCIDA" && ar.saldo.toNumber() <= 0) {
      throw new UnprocessableEntityError(
        "Cuenta vencida sin saldo pendiente",
        "AR_SIN_SALDO"
      );
    }

    // ── Validar monto pagado vs saldo ───────────────────────────────────────
    const saldoActual = ar.saldo.toNumber();
    if (dto.monto_pagado > saldoActual + 0.001) {
      throw new UnprocessableEntityError(
        `Monto pagado (${dto.monto_pagado}) supera el saldo pendiente (${saldoActual.toFixed(2)})`,
        "MONTO_EXCEDE_SALDO"
      );
    }

    // ── Determinar tipo de transacción original ──────────────────────────────
    const esConsignacion = ar.transaction.tipo === "CONSIGNACION";

    // ── Si es consignación: validar stock en ubicación del cliente ───────────
    let ubicacionConsignacion: { id: string } | null = null;

    if (esConsignacion) {
      ubicacionConsignacion = await prisma.inventoryLocation.findFirst({
        where: {
          tipo: "CONSIGNACION_CLIENTE",
          customer_id: ar.customer_id,
          activo: true,
        },
      });

      if (!ubicacionConsignacion) {
        throw new NotFoundError(
          "Ubicación de consignación del cliente no encontrada"
        );
      }

      // Verificar que haya stock suficiente para cada línea a liquidar
      const productIds = dto.lineas_liquidadas.map((l) => l.product_id);
      const stockConsignado = await prisma.inventoryItem.findMany({
        where: {
          location_id: ubicacionConsignacion.id,
          product_id: { in: productIds },
        },
      });

      const stockMap = new Map(
        stockConsignado.map((s) => [s.product_id, s.cantidad])
      );

      for (const linea of dto.lineas_liquidadas) {
        const disponible = stockMap.get(linea.product_id) ?? 0;
        if (disponible < linea.cantidad) {
          throw new UnprocessableEntityError(
            `Stock consignado insuficiente para producto ${linea.product_id}. Disponible: ${disponible}, Liquidado: ${linea.cantidad}`,
            "STOCK_CONSIGNADO_INSUFICIENTE"
          );
        }
      }
    }

    // ── Calcular total de líneas liquidadas ──────────────────────────────────
    const totalLineasLiquidadas = dto.lineas_liquidadas.reduce(
      (acc, l) => acc + l.cantidad * l.precio_unitario,
      0
    );

    // ── Determinar nuevo estado de la AR ─────────────────────────────────────
    const nuevoSaldo = Math.max(0, saldoActual - dto.monto_pagado);
    const pagoTotal = nuevoSaldo <= 0.001;
    const nuevoStatus = pagoTotal ? "CONCILIADA" : "PARCIAL";
    const nuevoEstadoNotificacion = pagoTotal ? "CONCILIADO" : ar.estado_notificacion;

    // =========================================================================
    // TRANSACCIÓN ATÓMICA
    // =========================================================================
    const result = await prisma.$transaction(
      async (tx) => {
        // 1. Crear registro de conciliación con sus líneas
        const conciliacion = await tx.conciliation.create({
          data: {
            account_receivable_id: ar.id,
            monto_pagado: new Prisma.Decimal(dto.monto_pagado),
            notas: dto.notas,
            conciliation_lines: {
              create: dto.lineas_liquidadas.map((l) => ({
                product_id: l.product_id,
                cantidad: l.cantidad,
                precio_unitario: new Prisma.Decimal(l.precio_unitario),
                subtotal: new Prisma.Decimal(l.cantidad * l.precio_unitario),
              })),
            },
          },
        });

        // 2. Actualizar cuenta por cobrar
        await tx.accountReceivable.update({
          where: { id: ar.id },
          data: {
            monto_pagado: {
              increment: new Prisma.Decimal(dto.monto_pagado),
            },
            saldo: new Prisma.Decimal(nuevoSaldo),
            status: nuevoStatus,
            estado_notificacion: nuevoEstadoNotificacion,
            ultimo_contacto_at: new Date(),
          },
        });

        // 3. Descontar saldo pendiente del cliente
        await tx.customer.update({
          where: { id: ar.customer_id },
          data: {
            saldo_pendiente: {
              decrement: new Prisma.Decimal(dto.monto_pagado),
            },
          },
        });

        // 4. Acreditar cobro en caja diaria activa (si existe)
        const cajaActiva = await tx.cashRegister.findFirst({
          where: { cerrada: false },
          orderBy: { fecha: "desc" },
        });

        if (cajaActiva) {
          await tx.cashRegister.update({
            where: { id: cajaActiva.id },
            data: {
              total_cobros: {
                increment: new Prisma.Decimal(dto.monto_pagado),
              },
            },
          });
        }

        // 5. Si es consignación: descontar stock consignado definitivamente
        if (esConsignacion && ubicacionConsignacion) {
          for (const linea of dto.lineas_liquidadas) {
            const updated = await tx.inventoryItem.updateMany({
              where: {
                location_id: ubicacionConsignacion.id,
                product_id: linea.product_id,
                cantidad: { gte: linea.cantidad }, // guard anti-race condition
              },
              data: { cantidad: { decrement: linea.cantidad } },
            });

            if (updated.count === 0) {
              throw new UnprocessableEntityError(
                `Condición de carrera en stock consignado del producto ${linea.product_id}`,
                "RACE_CONDITION_CONSIGNACION"
              );
            }
          }

          // Limpiar registros con stock 0 (housekeeping)
          await tx.inventoryItem.deleteMany({
            where: {
              location_id: ubicacionConsignacion.id,
              cantidad: { lte: 0 },
            },
          });
        }

        // 6. Audit log
        await tx.auditLog.create({
          data: {
            accion: pagoTotal ? "CONCILIACION_TOTAL" : "CONCILIACION_PARCIAL",
            tabla_afectada: "accounts_receivable",
            registro_id: ar.id,
            payload_before: {
              saldo: saldoActual,
              status: ar.status,
              estado_notificacion: ar.estado_notificacion,
            },
            payload_after: {
              saldo: nuevoSaldo,
              status: nuevoStatus,
              estado_notificacion: nuevoEstadoNotificacion,
              monto_pagado: dto.monto_pagado,
              conciliacion_id: conciliacion.id,
            },
            user_id: ar.transaction.vendedor_id,
            transaction_id: ar.transaction_id,
          },
        });

        return {
          conciliacion_id: conciliacion.id,
          account_receivable_id: ar.id,
          monto_pagado: dto.monto_pagado,
          saldo_anterior: saldoActual,
          saldo_restante: nuevoSaldo,
          status: nuevoStatus,
          estado_notificacion: nuevoEstadoNotificacion,
          lineas_liquidadas: dto.lineas_liquidadas.length,
          total_liquidado: totalLineasLiquidadas,
        };
      },
      {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        timeout: 10000,
      }
    );

    res.status(200).json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
}

// =============================================================================
// GET /api/v1/cobranza/:id — Consulta estado de una AR
// =============================================================================

export async function getAccountReceivable(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { id } = req.params;
    if (!id) throw new BadRequestError("ID requerido");

    const ar = await prisma.accountReceivable.findUnique({
      where: { id },
      include: {
        transaction: {
          select: {
            id: true,
            tipo: true,
            total: true,
            created_at: true,
            vendedor: { select: { nombre: true, apellido: true } },
          },
        },
        customer: {
          select: {
            id: true,
            razon_social: true,
            rfc: true,
            telefono: true,
          },
        },
        conciliations: {
          orderBy: { created_at: "desc" },
          include: { conciliation_lines: { include: { product: true } } },
        },
      },
    });

    if (!ar) throw new NotFoundError("Cuenta por cobrar no encontrada");

    res.status(200).json({ success: true, data: ar });
  } catch (err) {
    next(err);
  }
}


