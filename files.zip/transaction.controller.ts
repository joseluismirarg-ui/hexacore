import { Request, Response, NextFunction } from "express";
import { Prisma, TransactionType } from "@prisma/client";
import { prisma } from "../lib/prisma";
import {
  RegistrarTransaccionSchema,
  RegistrarTransaccionDTO,
} from "../validators/transaction.validator";
import {
  BadRequestError,
  UnprocessableEntityError,
  NotFoundError,
  InternalError,
} from "../lib/errors";

// =============================================================================
// POST /api/v1/transacciones/registrar
// =============================================================================

export async function registrarTransaccion(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const dto: RegistrarTransaccionDTO = RegistrarTransaccionSchema.parse(
      req.body
    );

    // ── Pre-validaciones fuera de la TX (lecturas rápidas) ──────────────────

    const customer = await prisma.customer.findUnique({
      where: { id: dto.customer_id, activo: true },
    });
    if (!customer) throw new NotFoundError("Cliente no encontrado o inactivo");

    const vendedor = await prisma.user.findUnique({
      where: { id: dto.vendedor_id, activo: true },
    });
    if (!vendedor) throw new NotFoundError("Vendedor no encontrado o inactivo");

    if (dto.cash_register_id) {
      const caja = await prisma.cashRegister.findUnique({
        where: { id: dto.cash_register_id },
      });
      if (!caja) throw new NotFoundError("Caja no encontrada");
      if (caja.cerrada)
        throw new UnprocessableEntityError("La caja ya está cerrada");
    }

    // ── Validar crédito disponible para CREDITO / CONSIGNACION ──────────────
    if (dto.tipo === "CREDITO" || dto.tipo === "CONSIGNACION") {
      const totalLineas = dto.lineas.reduce(
        (acc, l) => acc + l.cantidad * l.precio_unitario,
        0
      );
      const totalConDescuento = totalLineas - dto.descuento;
      const saldoDisponible =
        customer.limite_credito.toNumber() -
        customer.saldo_pendiente.toNumber();

      if (totalConDescuento > saldoDisponible) {
        throw new UnprocessableEntityError(
          `Límite de crédito insuficiente. Disponible: ${saldoDisponible.toFixed(2)}, Requerido: ${totalConDescuento.toFixed(2)}`,
          "CREDITO_INSUFICIENTE"
        );
      }
    }

    // ── Obtener Almacén Central ──────────────────────────────────────────────
    const almacenCentral = await prisma.inventoryLocation.findFirst({
      where: { tipo: "ALMACEN_CENTRAL", activo: true },
    });
    if (!almacenCentral)
      throw new InternalError("Almacén Central no configurado");

    // ── Verificar stock suficiente (lectura optimista pre-TX) ────────────────
    const productIds = dto.lineas.map((l) => l.product_id);
    const stockItems = await prisma.inventoryItem.findMany({
      where: {
        location_id: almacenCentral.id,
        product_id: { in: productIds },
      },
    });

    const stockMap = new Map(stockItems.map((s) => [s.product_id, s.cantidad]));
    for (const linea of dto.lineas) {
      const disponible = stockMap.get(linea.product_id) ?? 0;
      if (disponible < linea.cantidad) {
        throw new UnprocessableEntityError(
          `Stock insuficiente para producto ${linea.product_id}. Disponible: ${disponible}, Requerido: ${linea.cantidad}`,
          "STOCK_INSUFICIENTE"
        );
      }
    }

    // ── Calcular totales ─────────────────────────────────────────────────────
    const subtotal = dto.lineas.reduce(
      (acc, l) => acc + l.cantidad * l.precio_unitario,
      0
    );
    const total = Math.max(0, subtotal - dto.descuento);

    // =========================================================================
    // TRANSACCIÓN ATÓMICA
    // =========================================================================
    const result = await prisma.$transaction(
      async (tx) => {
        // 1. Crear la transacción maestra
        const transaction = await tx.transaction.create({
          data: {
            tipo: dto.tipo as TransactionType,
            status: "COMPLETADA",
            subtotal: new Prisma.Decimal(subtotal),
            descuento: new Prisma.Decimal(dto.descuento),
            total: new Prisma.Decimal(total),
            notas: dto.notas,
            customer_id: dto.customer_id,
            vendedor_id: dto.vendedor_id,
            cash_register_id:
              dto.tipo === "VENTA_DIRECTA"
                ? dto.cash_register_id ?? null
                : null,
            transaction_lines: {
              create: dto.lineas.map((l) => ({
                product_id: l.product_id,
                cantidad: l.cantidad,
                precio_unitario: new Prisma.Decimal(l.precio_unitario),
                subtotal: new Prisma.Decimal(l.cantidad * l.precio_unitario),
              })),
            },
          },
        });

        // 2. Mover stock del Almacén Central (aplica a todos los tipos)
        for (const linea of dto.lineas) {
          const updated = await tx.inventoryItem.updateMany({
            where: {
              location_id: almacenCentral.id,
              product_id: linea.product_id,
              cantidad: { gte: linea.cantidad }, // guard anti-race condition
            },
            data: { cantidad: { decrement: linea.cantidad } },
          });

          if (updated.count === 0) {
            throw new UnprocessableEntityError(
              `Condición de carrera detectada en stock del producto ${linea.product_id}`,
              "RACE_CONDITION_STOCK"
            );
          }
        }

        // ── Lógica diferenciada por tipo ─────────────────────────────────────

        if (dto.tipo === "VENTA_DIRECTA") {
          // Acreditar en caja diaria
          if (dto.cash_register_id) {
            await tx.cashRegister.update({
              where: { id: dto.cash_register_id },
              data: { total_ventas: { increment: new Prisma.Decimal(total) } },
            });
          }
        }

        if (dto.tipo === "CONSIGNACION") {
          // Obtener o crear ubicación de consignación para este cliente
          let ubicacionConsignacion = await tx.inventoryLocation.findFirst({
            where: {
              tipo: "CONSIGNACION_CLIENTE",
              customer_id: dto.customer_id,
              activo: true,
            },
          });

          if (!ubicacionConsignacion) {
            ubicacionConsignacion = await tx.inventoryLocation.create({
              data: {
                nombre: `Consignación — ${customer.razon_social}`,
                tipo: "CONSIGNACION_CLIENTE",
                customer_id: dto.customer_id,
              },
            });
          }

          // Transferir productos a inventario en consignación del cliente
          for (const linea of dto.lineas) {
            await tx.inventoryItem.upsert({
              where: {
                location_id_product_id: {
                  location_id: ubicacionConsignacion.id,
                  product_id: linea.product_id,
                },
              },
              update: { cantidad: { increment: linea.cantidad } },
              create: {
                location_id: ubicacionConsignacion.id,
                product_id: linea.product_id,
                cantidad: linea.cantidad,
              },
            });
          }

          // Crear cuenta por cobrar — NO toca la caja
          await tx.accountReceivable.create({
            data: {
              monto_original: new Prisma.Decimal(total),
              saldo: new Prisma.Decimal(total),
              fecha_vencimiento: dto.fecha_vencimiento ?? null,
              status: "ABIERTA",
              estado_notificacion: "IDLE",
              transaction_id: transaction.id,
              customer_id: dto.customer_id,
            },
          });

          // Actualizar saldo pendiente del cliente
          await tx.customer.update({
            where: { id: dto.customer_id },
            data: { saldo_pendiente: { increment: new Prisma.Decimal(total) } },
          });
        }

        if (dto.tipo === "CREDITO") {
          // Crear cuenta por cobrar y acreditar en caja
          await tx.accountReceivable.create({
            data: {
              monto_original: new Prisma.Decimal(total),
              saldo: new Prisma.Decimal(total),
              fecha_vencimiento: dto.fecha_vencimiento ?? null,
              status: "ABIERTA",
              estado_notificacion: "IDLE",
              transaction_id: transaction.id,
              customer_id: dto.customer_id,
            },
          });

          await tx.customer.update({
            where: { id: dto.customer_id },
            data: { saldo_pendiente: { increment: new Prisma.Decimal(total) } },
          });

          // Crédito sí afecta caja (venta comprometida)
          if (dto.cash_register_id) {
            await tx.cashRegister.update({
              where: { id: dto.cash_register_id },
              data: { total_ventas: { increment: new Prisma.Decimal(total) } },
            });
          }
        }

        // Audit log
        await tx.auditLog.create({
          data: {
            accion: `TRANSACCION_${dto.tipo}`,
            tabla_afectada: "transactions",
            registro_id: transaction.id,
            payload_after: {
              transaction_id: transaction.id,
              tipo: dto.tipo,
              total,
              customer_id: dto.customer_id,
            },
            user_id: dto.vendedor_id,
            transaction_id: transaction.id,
          },
        });

        return transaction;
      },
      {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        timeout: 10000,
      }
    );

    res.status(201).json({
      success: true,
      data: {
        transaction_id: result.id,
        tipo: result.tipo,
        status: result.status,
        total: result.total,
      },
    });
  } catch (err) {
    next(err);
  }
}
