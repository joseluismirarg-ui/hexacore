import { Router } from "express";
import {
  conciliarPago,
  getAccountReceivable,
} from "../controllers/cobranza.controller";

const router = Router();

/**
 * POST /api/v1/cobranza/conciliar-pago
 * Concilia un pago parcial o total contra una cuenta por cobrar.
 * Liquida el inventario consignado del cliente definitivamente.
 *
 * Body: ConciliarPagoDTO
 */
router.post("/conciliar-pago", conciliarPago);

/**
 * GET /api/v1/cobranza/:id
 * Consulta el estado completo de una cuenta por cobrar con su historial.
 */
router.get("/:id", getAccountReceivable);

export default router;
