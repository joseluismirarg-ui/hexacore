import { z } from "zod";

// ---------------------------------------------------------------------------
// Shared line item schema
// ---------------------------------------------------------------------------

const TransactionLineSchema = z.object({
  product_id: z.string().cuid({ message: "product_id debe ser un CUID válido" }),
  cantidad: z
    .number()
    .int({ message: "cantidad debe ser un entero" })
    .positive({ message: "cantidad debe ser mayor a 0" }),
  precio_unitario: z
    .number()
    .positive({ message: "precio_unitario debe ser mayor a 0" }),
});

// ---------------------------------------------------------------------------
// POST /api/v1/transacciones/registrar
// ---------------------------------------------------------------------------

export const RegistrarTransaccionSchema = z
  .object({
    tipo: z.enum(["VENTA_DIRECTA", "CREDITO", "CONSIGNACION"], {
      errorMap: () => ({
        message: "tipo debe ser VENTA_DIRECTA, CREDITO o CONSIGNACION",
      }),
    }),
    customer_id: z.string().cuid({ message: "customer_id inválido" }),
    vendedor_id: z.string().cuid({ message: "vendedor_id inválido" }),
    cash_register_id: z.string().cuid().optional(),
    descuento: z.number().min(0).default(0),
    notas: z.string().max(500).optional(),
    fecha_vencimiento: z.coerce.date().optional(),
    lineas: z
      .array(TransactionLineSchema)
      .min(1, { message: "Se requiere al menos una línea de producto" }),
  })
  .refine(
    (data) => {
      // CREDITO y CONSIGNACION requieren fecha de vencimiento
      if (
        (data.tipo === "CREDITO" || data.tipo === "CONSIGNACION") &&
        !data.fecha_vencimiento
      ) {
        return false;
      }
      return true;
    },
    {
      message:
        "fecha_vencimiento es obligatoria para transacciones de tipo CREDITO o CONSIGNACION",
      path: ["fecha_vencimiento"],
    }
  );

export type RegistrarTransaccionDTO = z.infer<typeof RegistrarTransaccionSchema>;

// ---------------------------------------------------------------------------
// POST /api/v1/cobranza/conciliar-pago
// ---------------------------------------------------------------------------

const ConciliacionLineSchema = z.object({
  product_id: z.string().cuid({ message: "product_id inválido" }),
  cantidad: z
    .number()
    .int()
    .positive({ message: "cantidad debe ser mayor a 0" }),
  precio_unitario: z
    .number()
    .positive({ message: "precio_unitario debe ser mayor a 0" }),
});

export const ConciliarPagoSchema = z.object({
  account_receivable_id: z
    .string()
    .cuid({ message: "account_receivable_id inválido" }),
  monto_pagado: z
    .number()
    .positive({ message: "monto_pagado debe ser mayor a 0" }),
  notas: z.string().max(500).optional(),
  lineas_liquidadas: z
    .array(ConciliacionLineSchema)
    .min(1, { message: "Se requiere al menos una línea liquidada" }),
});

export type ConciliarPagoDTO = z.infer<typeof ConciliarPagoSchema>;
