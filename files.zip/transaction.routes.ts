import { Router } from "express";
import { registrarTransaccion } from "../controllers/transaction.controller";

const router = Router();

/**
 * POST /api/v1/transacciones/registrar
 * Registra una nueva transacción: VENTA_DIRECTA | CREDITO | CONSIGNACION
 *
 * Body: RegistrarTransaccionDTO
 */
router.post("/registrar", registrarTransaccion);

export default router;
